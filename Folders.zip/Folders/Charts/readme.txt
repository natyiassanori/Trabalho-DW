Edit the publish.vbs and open.vbs scripts to upload your charts to a ftp site.
